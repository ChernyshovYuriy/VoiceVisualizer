"""Core audio pipeline."""
